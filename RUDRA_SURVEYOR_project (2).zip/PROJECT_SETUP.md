# Project setup notes

This ZIP is a Flutter project starter with the supplied RUDRA SURVEYOR artwork already included.

Included:
- Gujarati / English toggle
- Home dashboard
- Land Measurement
- Area Calculator
- Unit Converter
- Surveyor Knowledge
- Survey Report preview/share
- Customer Care 8487847474
- Android launcher icons
- Android splash artwork
- Codemagic workflows for Android and iOS

To make the project a fully generated Flutter platform tree, run:
`flutter create .`

Run it from this directory after extracting. Flutter will create/refresh any standard platform
files that are not included in this starter while preserving lib/, assets/, pubspec.yaml and codemagic.yaml.
