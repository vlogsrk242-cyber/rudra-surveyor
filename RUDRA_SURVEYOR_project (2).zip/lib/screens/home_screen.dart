import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'area_calculator_screen.dart';
import 'measurement_screen.dart';
import 'converter_screen.dart';
import 'knowledge_screen.dart';
import 'report_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool gujarati = true;

  String t(String gu, String en) => gujarati ? gu : en;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(t('RUDRA SURVEYOR', 'RUDRA SURVEYOR')),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: true, label: Text('ગુજ')),
                ButtonSegment(value: false, label: Text('EN')),
              ],
              selected: {gujarati},
              onSelectionChanged: (s) => setState(() => gujarati = s.first),
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: Image.asset('assets/images/rudra_logo.jpg', height: 230, fit: BoxFit.cover),
          ),
          const SizedBox(height: 18),
          Text(
            t('સર્વે માટે એક જ સ્માર્ટ ટૂલકિટ', 'One smart toolkit for survey work'),
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          Text(t('DGPS • DRONE • TOTAL STATION SURVEY', 'DGPS • DRONE • TOTAL STATION SURVEY')),
          const SizedBox(height: 18),
          _card(context, Icons.straighten, t('જમીન માપણી', 'Land Measurement'),
              t('લંબાઈ, પહોળાઈ અને આકાર પરથી ક્ષેત્રફળ', 'Calculate area from dimensions and shapes'),
              const MeasurementScreen()),
          _card(context, Icons.calculate, t('એરિયા કેલ્ક્યુલેટર', 'Area Calculator'),
              t('Rectangle, triangle અને circle', 'Rectangle, triangle and circle'),
              const AreaCalculatorScreen()),
          _card(context, Icons.swap_horiz, t('યુનિટ કન્વર્ટર', 'Unit Converter'),
              t('માપના વિવિધ એકમોમાં રૂપાંતર', 'Convert common measurement units'),
              const ConverterScreen()),
          _card(context, Icons.menu_book, t('સર્વેયર જ્ઞાન', 'Surveyor Knowledge'),
              t('ફિલ્ડમાં ઉપયોગી માહિતી અને ચેકલિસ્ટ', 'Useful field information and checklists'),
              const KnowledgeScreen()),
          _card(context, Icons.description, t('સર્વે રિપોર્ટ', 'Survey Report'),
              t('ક્લાયન્ટ માટે રિપોર્ટની વિગતો તૈયાર કરો', 'Prepare survey report details'),
              const ReportScreen()),
          const SizedBox(height: 10),
          Card(
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.phone)),
              title: Text(t('Customer Care', 'Customer Care')),
              subtitle: const Text('8487847474'),
              trailing: IconButton(
                icon: const Icon(Icons.call),
                onPressed: () => launchUrl(Uri.parse('tel:8487847474')),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _card(BuildContext context, IconData icon, String title, String subtitle, Widget page) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: CircleAvatar(child: Icon(icon)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.arrow_forward_ios, size: 18),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => page)),
      ),
    );
  }
}
