import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

class ReportScreen extends StatefulWidget {
  const ReportScreen({super.key});
  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  final client = TextEditingController();
  final site = TextEditingController();
  final surveyDate = TextEditingController();
  final area = TextEditingController();
  final remarks = TextEditingController();

  String buildReport() => '''
RUDRA SURVEYOR
DGPS • DRONE • TOTAL STATION SURVEY

SURVEY REPORT
Client: ${client.text}
Site: ${site.text}
Date: ${surveyDate.text}
Measured Area: ${area.text}

Remarks:
${remarks.text}

Customer Care: 8487847474
''';

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Survey Report')),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        TextField(controller: client, decoration: const InputDecoration(labelText: 'Client Name')),
        const SizedBox(height: 10),
        TextField(controller: site, decoration: const InputDecoration(labelText: 'Site / Location')),
        const SizedBox(height: 10),
        TextField(controller: surveyDate, decoration: const InputDecoration(labelText: 'Survey Date')),
        const SizedBox(height: 10),
        TextField(controller: area, decoration: const InputDecoration(labelText: 'Measured Area')),
        const SizedBox(height: 10),
        TextField(controller: remarks, maxLines: 5, decoration: const InputDecoration(labelText: 'Remarks')),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: () => Share.share(buildReport(), subject: 'RUDRA SURVEYOR Survey Report'),
          icon: const Icon(Icons.share),
          label: const Text('Share Report'),
        ),
        const SizedBox(height: 12),
        OutlinedButton(
          onPressed: () => showDialog(context: context, builder: (_) => AlertDialog(
            title: const Text('Report Preview'),
            content: SingleChildScrollView(child: Text(buildReport())),
            actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
          )),
          child: const Text('Preview'),
        ),
      ],
    ),
  );
}
