import 'package:flutter/material.dart';

class ConverterScreen extends StatefulWidget {
  const ConverterScreen({super.key});
  @override
  State<ConverterScreen> createState() => _ConverterScreenState();
}

class _ConverterScreenState extends State<ConverterScreen> {
  final input = TextEditingController();
  String from = 'Meter', to = 'Feet';
  double output = 0;

  final factors = const {
    'Meter': 1.0,
    'Feet': 0.3048,
    'Yard': 0.9144,
    'Kilometer': 1000.0,
    'Centimeter': 0.01,
    'Millimeter': 0.001,
  };

  void convert() {
    final v = double.tryParse(input.text) ?? 0;
    final meters = v * factors[from]!;
    setState(() => output = meters / factors[to]!);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Unit Converter')),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        TextField(controller: input, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Value')),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: _drop('From', from, (v) => setState(() => from = v!))),
          const SizedBox(width: 10),
          Expanded(child: _drop('To', to, (v) => setState(() => to = v!))),
        ]),
        const SizedBox(height: 16),
        FilledButton(onPressed: convert, child: const Text('Convert')),
        const SizedBox(height: 18),
        Card(child: Padding(padding: const EdgeInsets.all(20),
          child: Text(output.toStringAsFixed(6), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)))),
        const SizedBox(height: 10),
        const Text('Units included: meter, feet, yard, kilometer, centimeter, millimeter.'),
      ],
    ),
  );

  Widget _drop(String label, String value, ValueChanged<String?> onChanged) =>
    DropdownButtonFormField<String>(
      value: value, decoration: InputDecoration(labelText: label),
      items: factors.keys.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
      onChanged: onChanged,
    );
}
