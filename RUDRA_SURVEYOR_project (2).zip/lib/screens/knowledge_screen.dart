import 'package:flutter/material.dart';

class KnowledgeScreen extends StatelessWidget {
  const KnowledgeScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Surveyor Knowledge')),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: const [
        _Info(title: 'DGPS', text: 'Differential GNSS can provide high-precision positioning when used with suitable corrections, control points and field procedures.'),
        _Info(title: 'Total Station', text: 'A total station measures angles and distances and is commonly used for traverse, detail survey and setting-out work.'),
        _Info(title: 'Drone Survey', text: 'Plan flight overlap, ground control/check points, safe operating conditions and appropriate processing before relying on an orthomosaic or surface model.'),
        _Info(title: 'Field Checklist', text: 'Check instrument calibration, battery, prism/target, coordinate system, benchmark/control, weather, project boundary and data backup.'),
        _Info(title: 'Coordinate Systems', text: 'Always confirm datum, projection, units, vertical reference and project origin before combining datasets.'),
      ],
    ),
  );
}

class _Info extends StatelessWidget {
  final String title, text;
  const _Info({required this.title, required this.text});
  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.only(bottom: 12),
    child: ExpansionTile(
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      children: [Padding(padding: const EdgeInsets.all(16), child: Text(text))],
    ),
  );
}
