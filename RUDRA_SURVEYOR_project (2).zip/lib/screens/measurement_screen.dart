import 'package:flutter/material.dart';

class MeasurementScreen extends StatefulWidget {
  const MeasurementScreen({super.key});
  @override
  State<MeasurementScreen> createState() => _MeasurementScreenState();
}

class _MeasurementScreenState extends State<MeasurementScreen> {
  final a = TextEditingController();
  final b = TextEditingController();
  String unit = 'm';
  double result = 0;

  void calculate() {
    final x = double.tryParse(a.text) ?? 0;
    final y = double.tryParse(b.text) ?? 0;
    setState(() => result = x * y);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Land Measurement')),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('Rectangle / Plot estimate', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        TextField(controller: a, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: 'Length ($unit)')),
        const SizedBox(height: 10),
        TextField(controller: b, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: 'Width ($unit)')),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(
          value: unit,
          decoration: const InputDecoration(labelText: 'Unit'),
          items: const ['m', 'ft'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
          onChanged: (v) => setState(() => unit = v ?? 'm'),
        ),
        const SizedBox(height: 16),
        FilledButton.icon(onPressed: calculate, icon: const Icon(Icons.calculate), label: const Text('Calculate Area')),
        const SizedBox(height: 18),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Text('Area: ${result.toStringAsFixed(4)} $unit²', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          ),
        ),
        const SizedBox(height: 12),
        const Text('Note: This is an estimation utility. Official/legal measurements should be based on approved survey procedures and calibrated instruments.'),
      ],
    ),
  );
}
