import 'dart:math' as math;
import 'package:flutter/material.dart';

class AreaCalculatorScreen extends StatefulWidget {
  const AreaCalculatorScreen({super.key});
  @override
  State<AreaCalculatorScreen> createState() => _AreaCalculatorScreenState();
}

class _AreaCalculatorScreenState extends State<AreaCalculatorScreen> {
  String shape = 'Rectangle';
  final x = TextEditingController();
  final y = TextEditingController();
  double area = 0;

  void calc() {
    final a = double.tryParse(x.text) ?? 0;
    final b = double.tryParse(y.text) ?? 0;
    setState(() {
      if (shape == 'Rectangle') area = a * b;
      else if (shape == 'Triangle') area = 0.5 * a * b;
      else area = math.pi * a * a;
    });
  }

  @override
  Widget build(BuildContext context) {
    final secondLabel = shape == 'Circle' ? 'Radius' : 'Width / Height';
    return Scaffold(
      appBar: AppBar(title: const Text('Area Calculator')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          DropdownButtonFormField<String>(
            value: shape,
            decoration: const InputDecoration(labelText: 'Shape'),
            items: const ['Rectangle', 'Triangle', 'Circle']
                .map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
            onChanged: (v) => setState(() => shape = v ?? 'Rectangle'),
          ),
          const SizedBox(height: 12),
          TextField(controller: x, keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: shape == 'Circle' ? 'Radius' : 'Length / Base')),
          if (shape != 'Circle') ...[
            const SizedBox(height: 12),
            TextField(controller: y, keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: secondLabel)),
          ],
          const SizedBox(height: 16),
          FilledButton(onPressed: calc, child: const Text('Calculate')),
          const SizedBox(height: 16),
          Text('Area = ${area.toStringAsFixed(4)} square units',
              style: Theme.of(context).textTheme.headlineSmall),
        ],
      ),
    );
  }
}
