# RUDRA SURVEYOR

Gujarati + English surveyor utility app for:
- Land Measurement
- Area Calculator
- Unit Converter
- Surveyor Knowledge / Information
- Survey Report
- Customer Care: 8487847474
- DGPS / Drone / Total Station survey workflow starter

## Run locally

```bash
flutter pub get
flutter run
```

## Build

```bash
flutter build apk --release
flutter build appbundle --release
```

## Codemagic

The project includes `codemagic.yaml`.

1. Push this folder to GitHub.
2. Create/connect the app in Codemagic.
3. Configure Android signing with the keystore reference `rudra_keystore`.
4. For iOS, configure Apple signing credentials/team in Codemagic.
5. Start the required workflow.

## Important

The app contains calculation utilities intended for field estimation. For legal land records,
cadastral boundaries, and official measurements, use the applicable government/registered-surveyor
workflow and calibrated instruments.
